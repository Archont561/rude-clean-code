"""Abstract base API for executing commands within tox environments."""

from __future__ import annotations

import logging
import sys
import time
from abc import ABC, abstractmethod
from collections.abc import Callable, Generator, Sequence
from contextlib import contextmanager, suppress
from typing import IO, TYPE_CHECKING, NoReturn, cast

from colorama import Fore

from tox.util.typing_compat import override

from .request import ExecuteRequest, StdinSource
from .stream import SyncWrite

if TYPE_CHECKING:
    from types import TracebackType

    from tox.report import OutErr
    from tox.tox_env.api import ToxEnv
    from tox.util.json_types import JsonValue

ContentHandler = Callable[[bytes], int]
Executor = Callable[[ExecuteRequest, ContentHandler, ContentHandler], int]
LOGGER = logging.getLogger(__name__)


class ExecuteOptions:
    def __init__(self, env: ToxEnv) -> None:
        self._env = env

    @classmethod
    def register_conf(cls, env: ToxEnv) -> None:
        env.conf.add_config(
            keys=["suicide_timeout"],
            desc="timeout to allow process to exit before sending SIGINT",
            of_type=float,
            default=0.0,
        )
        env.conf.add_config(
            keys=["interrupt_timeout"],
            desc="timeout before sending SIGTERM after SIGINT",
            of_type=float,
            default=0.3,
        )
        env.conf.add_config(
            keys=["terminate_timeout"],
            desc="timeout before sending SIGKILL after SIGTERM",
            of_type=float,
            default=0.2,
        )

    @property
    def suicide_timeout(self) -> float:
        return cast("float", self._env.conf["suicide_timeout"])

    @property
    def interrupt_timeout(self) -> float:
        return cast("float", self._env.conf["interrupt_timeout"])

    @property
    def terminate_timeout(self) -> float:
        return cast("float", self._env.conf["terminate_timeout"])

    @property
    def no_capture(self) -> bool:
        return cast("bool", getattr(self._env.options, "no_capture", False))


class ExecuteStatus(ABC):
    def __init__(self, options: ExecuteOptions, out: SyncWrite, err: SyncWrite) -> None:
        self.outcome: Outcome | None = None
        self.options = options
        self._out = out
        self._err = err

    @property
    @abstractmethod
    def exit_code(self) -> int | None:
        raise NotImplementedError

    @property
    def start_error(self) -> BaseException | None:
        """:returns: the error that kept the command from starting, ``None`` once it started"""
        return None

    @abstractmethod
    def wait(self, timeout: float | None = None) -> int | None:
        raise NotImplementedError

    @abstractmethod
    def write_stdin(self, content: str) -> None:
        raise NotImplementedError

    @abstractmethod
    def interrupt(self) -> None:
        raise NotImplementedError

    def set_out_err(self, out: SyncWrite, err: SyncWrite) -> tuple[SyncWrite, SyncWrite]:
        res = self._out, self._err
        self._out, self._err = out, err
        return res

    @property
    def out(self) -> bytearray:
        return self._out.content

    @property
    def err(self) -> bytearray:
        return self._err.content

    @property
    def metadata(self) -> dict[str, JsonValue]:
        return {}


class FinishedExecuteStatus(ExecuteStatus):
    """Report a fixed exit code for a command that finished or never started, without running a process."""

    def __init__(self, options: ExecuteOptions, out: SyncWrite, err: SyncWrite, exit_code: int | None) -> None:
        super().__init__(options, out, err)
        self._exit_code = exit_code

    @property
    @override
    def exit_code(self) -> int | None:
        return self._exit_code

    @override
    def wait(self, timeout: float | None = None) -> int | None:
        return self._exit_code

    @override
    def write_stdin(self, content: str) -> None:
        """Cannot write."""

    @override
    def interrupt(self) -> None:
        return None  # nothing running so nothing to interrupt


class Execute(ABC):
    """Abstract API for execution of a tox environment."""

    _option_class: type[ExecuteOptions] = ExecuteOptions

    def __init__(self, colored: bool) -> None:  # ruff:ignore[boolean-type-hint-positional-argument]
        self._colored = colored

    @contextmanager
    def call(
        self,
        request: ExecuteRequest,
        show: bool,  # ruff:ignore[boolean-type-hint-positional-argument]
        out_err: OutErr,
        env: ToxEnv,
    ) -> Generator[ExecuteStatus, None, None]:
        start = time.monotonic()
        stderr_color = None
        if self._colored:
            try:
                cfg_color = env.conf._conf.options.stderr_color  # ruff:ignore[private-member-access]
                stderr_color = getattr(Fore, cfg_color)
            except (AttributeError, KeyError, TypeError):  # many tests have a mocked 'env'
                stderr_color = Fore.RED
            if sys.platform == "win32" and show:
                try:
                    from colorama.winterm import enable_vt_processing  # ruff:ignore[import-outside-top-level]

                    for stream in out_err:
                        with suppress(AttributeError, OSError):
                            enable_vt_processing(stream.buffer.fileno())  # pragma: win32 cover
                except ImportError:
                    pass
        # collector is what forwards the content from the file streams to the standard streams
        out = cast("IO[bytes]", out_err[0].buffer)
        err = cast("IO[bytes]", out_err[1].buffer)
        out_sync = SyncWrite(out.name, out if show else None)
        err_sync = SyncWrite(err.name, err if show else None, str(stderr_color) if stderr_color is not None else None)
        try:
            with out_sync, err_sync:
                instance = self.build_instance(request, self._option_class(env), out_sync, err_sync)
                with instance as status:
                    yield status
                exit_code = status.exit_code
        finally:
            end = time.monotonic()
        status.outcome = Outcome(
            request,
            show,
            exit_code,
            out_sync.text,
            err_sync.text,
            start,
            end,
            instance.cmd,
            status.metadata,
            status.start_error,
        )

    @abstractmethod
    def build_instance(
        self,
        request: ExecuteRequest,
        options: ExecuteOptions,
        out: SyncWrite,
        err: SyncWrite,
    ) -> ExecuteInstance:
        raise NotImplementedError

    @classmethod
    def register_conf(cls, env: ToxEnv) -> None:
        cls._option_class.register_conf(env)


class ExecuteInstance(ABC):
    """An instance of a command execution."""

    def __init__(self, request: ExecuteRequest, options: ExecuteOptions, out: SyncWrite, err: SyncWrite) -> None:
        self.request = request
        self.options = options
        self._out = out
        self._err = err

    @property
    def out_handler(self) -> ContentHandler:
        return self._out.handler

    @property
    def err_handler(self) -> ContentHandler:
        return self._err.handler

    @abstractmethod
    def __enter__(self) -> ExecuteStatus:
        raise NotImplementedError

    @abstractmethod
    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        raise NotImplementedError

    @property
    @abstractmethod
    def cmd(self) -> Sequence[str]:
        raise NotImplementedError


class Outcome:
    """Result of a command execution."""

    OK = 0
    FAILED = 1  #: exit code reported when a ``!`` command exits with :attr:`OK`

    def __init__(  # ruff:ignore[too-many-arguments]
        self,
        request: ExecuteRequest,
        show_on_standard: bool,  # ruff:ignore[boolean-type-hint-positional-argument]
        exit_code: int | None,
        out: str,
        err: str,
        start: float,
        end: float,
        cmd: Sequence[str],
        metadata: dict[str, JsonValue],
        start_error: BaseException | None = None,
    ) -> None:
        """Create a new execution outcome.

        :param request: the execution request
        :param show_on_standard: a flag indicating if the execution was shown on stdout/stderr
        :param exit_code: the exit code for the execution
        :param out: the standard output of the execution
        :param err: the standard error of the execution
        :param start: a timer sample for the start of the execution
        :param end: a timer sample for the end of the execution
        :param cmd: the command as executed
        :param metadata: additional metadata attached to the execution
        :param start_error: the error that kept the command from starting, ``None`` once it started

        """
        self.request = request  #: the execution request
        self.show_on_standard = show_on_standard  #: a flag indicating if the execution was shown on stdout/stderr
        self.exit_code = exit_code  #: the exit code for the execution
        self.out = out  #: the standard output of the execution
        self.err = err  #: the standard error of the execution
        self.start = start  #: a timer sample for the start of the execution
        self.end = end  #: a timer sample for the end of the execution
        self.cmd = cmd  #: the command as executed
        self.metadata = metadata  #: additional metadata attached to the execution
        self.start_error = start_error  #: the error that kept the command from starting, ``None`` once it started

    def __bool__(self) -> bool:
        return self.exit_code == self.OK

    @override
    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}: exit {self.exit_code} in {self.elapsed:.2f} seconds"
            f" for {self.request.shell_cmd_redacted}"
        )

    def assert_success(self) -> None:
        """Assert that the execution succeeded."""
        if self.start_error is not None or self.exit_code not in {None, self.OK}:
            self._assert_fail(self.exit_code or self.FAILED)
        self.log_run_done(logging.INFO)

    def assert_failure(self) -> None:
        """Assert that the execution failed."""
        if self.start_error is not None or self.exit_code == self.OK:  # never started, so nothing to invert
            self._assert_fail(self.exit_code or self.FAILED)
        self.log_run_done(logging.INFO)

    def _assert_fail(self, code: int) -> NoReturn:
        if self.show_on_standard is False:
            if self.out:
                sys.stdout.write(self.out)
                if not self.out.endswith("\n"):
                    sys.stdout.write("\n")
            if self.err:
                sys.stderr.write(str(Fore.RED))
                sys.stderr.write(self.err)
                sys.stderr.write(str(Fore.RESET))
                if not self.err.endswith("\n"):
                    sys.stderr.write("\n")
        self.log_run_done(logging.CRITICAL)
        raise SystemExit(code)

    def log_run_done(self, lvl: int) -> None:
        """Log that the run was done.

        :param lvl: the level on what to log as interpreted by :func:`logging.log`

        """
        req = self.request
        metadata = ""
        if self.metadata:
            metadata = f" {', '.join(f'{k}={v}' for k, v in self.metadata.items())}"
        LOGGER.log(
            lvl,
            "exit %s (%.2f seconds) %s> %s%s",
            self.exit_code,
            self.elapsed,
            req.cwd,
            req.shell_cmd_redacted,
            metadata,
        )

    @property
    def elapsed(self) -> float:
        """:returns: time the execution took in seconds"""
        return self.end - self.start

    def out_err(self) -> tuple[str, str]:
        """:returns: a tuple of the standard output and standard error"""
        return self.out, self.err


__all__ = (
    "ContentHandler",
    "Execute",
    "ExecuteInstance",
    "ExecuteOptions",
    "ExecuteStatus",
    "FinishedExecuteStatus",
    "Outcome",
    "StdinSource",
)
