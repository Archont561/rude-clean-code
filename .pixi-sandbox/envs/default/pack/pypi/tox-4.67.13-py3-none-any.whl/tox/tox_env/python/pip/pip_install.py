from __future__ import annotations

import hashlib
import json
import logging
import operator
import re
import sys
from abc import ABC, abstractmethod
from collections import defaultdict
from collections.abc import Callable, Sequence
from functools import partial
from pathlib import Path
from typing import TYPE_CHECKING, Any, Final
from urllib.error import URLError
from urllib.parse import parse_qs, urlsplit

from packaging.requirements import Requirement
from packaging.utils import NormalizedName, canonicalize_name

from tox.config.types import Command
from tox.execute.request import StdinSource
from tox.tox_env.errors import Fail, Recreate
from tox.tox_env.installer import InstallArguments, Installer
from tox.tox_env.python.api import Python
from tox.tox_env.python.package import EditableLegacyPackage, EditablePackage, SdistPackage, WheelPackage
from tox.tox_env.python.pip.req_file import PythonConstraints, PythonDeps
from tox.tox_env.python.pylock import Pylock
from tox.util.typing_compat import override

if TYPE_CHECKING:
    from tox.config.main import Config
    from tox.tox_env.package import Package
    from tox.tox_env.python.pip.req.file import ParsedRequirement
    from tox.util.json_types import JsonValue

_REDACTION_FORMAT: Final[int] = 1


class PythonInstallerListDependencies(Installer[Python], ABC):
    def __init__(self, tox_env: Python, with_list_deps: bool = True) -> None:  # ruff:ignore[boolean-type-hint-positional-argument, boolean-default-value-positional-argument]
        self._with_list_deps = with_list_deps
        super().__init__(tox_env)

    @override
    def _register_config(self) -> None:
        if self._with_list_deps:  # pragma: no branch
            self._env.conf.add_config(
                keys=["list_dependencies_command"],
                of_type=Command,
                default=Command(self.freeze_cmd()),
                desc="command used to list installed packages",
            )

    @abstractmethod
    def freeze_cmd(self) -> list[str]:
        raise NotImplementedError

    @override
    def installed(self) -> list[str]:
        cmd = self._env.conf.get("list_dependencies_command", Command)
        result = self._env.execute(cmd=cmd.args, stdin=StdinSource.OFF, run_id="freeze", show=False, capture=True)
        result.assert_success()
        return result.out.splitlines()


_PIP_RESOLUTION_ENV_VARS: frozenset[str] = frozenset({
    "PIP_CONSTRAINT",
    "PIP_EXTRA_INDEX_URL",
    "PIP_FIND_LINKS",
    "PIP_INDEX_URL",
    "PIP_NO_INDEX",
    "PIP_PRE",
    "PIP_REQUIRE_HASHES",
    "PIP_TRUSTED_HOST",
})


class Pip(PythonInstallerListDependencies):
    """Pip is a python installer that can install packages as defined by PEP-508 and PEP-517."""

    @override
    def _register_config(self) -> None:
        super()._register_config()
        root = self._env.core["toxinidir"]
        self._env.conf.add_config(
            keys=["pip_pre"],
            of_type=bool,
            default=False,
            desc="install the latest available pre-release (alpha/beta/rc) of dependencies without a specified version",
        )
        self._env.conf.add_config(
            keys=["install_command"],
            of_type=Command,
            default=self.default_install_command,
            post_process=self.post_process_install_command,
            desc="command used to install packages",
        )
        self._env.conf.add_config(
            keys=["constraints"],
            of_type=PythonConstraints,
            factory=partial(
                PythonConstraints.factory, root, environment_provider=lambda: self._env.environment_variables
            ),
            default=PythonConstraints("", root),
            desc="constraints to apply to installed python dependencies",
        )
        self._env.conf.add_config(
            keys=["constrain_package_deps"],
            of_type=bool,
            default=False,
            desc="If true, apply constraints during install_package_deps.",
        )
        self._env.conf.add_config(
            keys=["use_frozen_constraints"],
            of_type=bool,
            default=False,
            desc="Use the exact versions of installed deps as constraints, otherwise use the listed deps.",
        )

    @override
    def freeze_cmd(self) -> list[str]:
        return ["python", "-m", "pip", "freeze", "--all"]

    def default_install_command(self, conf: Config, env_name: str | None) -> Command:  # ruff:ignore[unused-method-argument]
        isolated_flag = "-E" if self._env.base_python.version_info.major == 2 else "-I"  # ruff:ignore[magic-value-comparison]
        return Command(["python", isolated_flag, "-m", "pip", "install", "{opts}", "{packages}"])

    def post_process_install_command(self, cmd: Command) -> Command:
        install_command = cmd.args
        pip_pre = self._env.conf.get("pip_pre", bool)
        try:
            opts_at = install_command.index("{opts}")
        except ValueError:
            if pip_pre:
                install_command.append("--pre")
        else:
            if pip_pre:
                install_command[opts_at] = "--pre"
            else:
                install_command.pop(opts_at)
        return cmd

    @override
    def install(self, arguments: InstallArguments, section: str, of_type: str) -> None:
        if isinstance(arguments, PythonDeps):
            self._install_requirement_file(arguments, section, of_type)
        elif isinstance(arguments, Pylock):
            self._install_pylock(arguments, section, of_type)
        elif isinstance(arguments, Sequence):
            self._install_list_of_deps(arguments, section, of_type)
        else:
            logging.warning("pip cannot install %r", arguments)
            raise SystemExit(1)

    @property
    def constraints(self) -> PythonConstraints:
        return self._env.conf.get("constraints", PythonConstraints)

    def constraints_file(self) -> Path:
        return Path(self._env.env_dir) / "constraints.txt"

    @property
    def constrain_package_deps(self) -> bool:
        return bool(self._env.conf["constrain_package_deps"])

    @property
    def use_frozen_constraints(self) -> bool:
        return bool(self._env.conf["use_frozen_constraints"])

    def _install_requirement_file(self, arguments: PythonDeps, section: str, of_type: str) -> None:
        new_requirements: list[str] = []
        new_constraints: list[str] = []

        try:
            new_options, new_reqs = arguments.unroll()
        except (ValueError, URLError) as exception:
            msg = f"{arguments.redact(str(exception))} for tox env py within deps"
            raise Fail(msg) from None
        for req in new_reqs:
            (new_constraints if req.startswith("-c ") else new_requirements).append(req)

        try:
            _, new_reqs = self.constraints.unroll()
        except (ValueError, URLError) as exception:
            msg = f"{self.constraints.redact(str(exception))} for tox env py within constraints"
            raise Fail(msg) from None
        new_constraints.extend(new_reqs)

        constraint_options: Final = {
            "constrain_package_deps": self.constrain_package_deps,
            "use_frozen_constraints": self.use_frozen_constraints,
        }
        new: Final = {
            "redaction_format": _REDACTION_FORMAT,
            "options": new_options,
            "requirements": new_requirements,
            "constraints": new_constraints,
            "constraint_options": constraint_options,
            "env": self._install_env_vars(),
        }
        # if option or constraint change in any way recreate, if the requirements change only if some are removed
        with self._env.cache.compare(new, section, of_type) as (eq, old):
            if not eq:  # pragma: no branch
                if old is not None:
                    if old.get("redaction_format") != _REDACTION_FORMAT:
                        msg = "install cache format changed"
                        raise Recreate(msg)
                    self._recreate_if_diff("install flag(s)", new_options, old["options"], lambda i: i)
                    self._recreate_if_diff(
                        "constraint(s)", new_constraints, old["constraints"], operator.itemgetter(slice(3, None))
                    )
                    missing_requirement = set(old["requirements"]) - set(new_requirements)
                    if missing_requirement:
                        msg = f"requirements removed: {' '.join(missing_requirement)}"
                        raise Recreate(msg)
                    old_constraint_options = old.get("constraint_options")
                    if old_constraint_options != constraint_options:
                        msg = f"constraint options changed: old={old_constraint_options} new={constraint_options}"
                        raise Recreate(msg)
                args = arguments.as_root_args
                if args:  # pragma: no branch
                    args.extend(self.constraints.as_root_args)
                    self._execute_installer(args, of_type)
                    self._write_combined_constraints(arguments)

    def _write_combined_constraints(self, arguments: PythonDeps) -> None:
        if self.constrain_package_deps and not self.use_frozen_constraints and not self._has_constraints:
            combined_constraints: Final = [
                line for req in arguments.requirements if (line := self._as_constraint(req)) is not None
            ]
            combined_constraints.extend(
                str(req).removeprefix("-c ") for req in arguments.requirements if req.options.get("is_constraint")
            )
            combined_constraints.extend(str(req).removeprefix("-c ") for req in self.constraints.requirements)
            self.constraints_file().write_text("\n".join(combined_constraints))

    @staticmethod
    def _recreate_if_diff(of_type: str, new_opts: list[str], old_opts: list[str], fmt: Callable[[str], str]) -> None:
        if old_opts == new_opts:
            return
        removed_opts = set(old_opts) - set(new_opts)
        removed = f" removed {', '.join(sorted(fmt(i) for i in removed_opts))}" if removed_opts else ""
        added_opts = set(new_opts) - set(old_opts)
        added = f" added {', '.join(sorted(fmt(i) for i in added_opts))}" if added_opts else ""
        msg = f"changed {of_type}{removed}{added}"
        raise Recreate(msg)

    @staticmethod
    def _as_constraint(req: ParsedRequirement) -> str | None:
        # pip rejects extras, editables and anything it cannot name (a directory or sdist) in a constraints file
        if req.options.get("is_constraint") or req.options.get("is_editable"):
            return None
        if isinstance(req.requirement, Requirement):
            named = Requirement(str(req.requirement))
            named.extras = set()
            line = str(named)
        elif not Pip._pip_can_name(line := re.sub(r"\[[^\]]*\]$", "", str(req.requirement))):
            return None
        return " ".join([line, *(f"--hash {value}" for value in req.options.get("hash", []))])

    @staticmethod
    def _pip_can_name(line: str) -> bool:
        # pip names a wheel from its file name and a URL from its egg fragment
        if "://" not in line:
            return line.endswith(".whl")
        url = urlsplit(line)
        return url.path.endswith(".whl") or "egg" in parse_qs(url.fragment)

    def _install_pylock(self, pylock: Pylock, section: str, of_type: str) -> None:
        new_reqs = sorted(pylock.install_lines())
        environment = self._env.environment_variables
        if sys.platform == "win32":
            # pip sees Windows environment variable names without case distinctions.
            environment = {name.upper(): value for name, value in environment.items()}
        referenced: Final[dict[str, str]] = {
            name: value
            for line in new_reqs
            for name in re.findall(r"\$\{([A-Z0-9_]+)\}", line)
            if (value := environment.get(name))
        }
        for name, value in referenced.items():
            if any(char.isspace() or not char.isprintable() for char in value):
                msg = f"pylock environment variable {name} contains whitespace or control characters"
                raise Fail(msg)
        cache_value: Final[dict[str, JsonValue]] = {"req": new_reqs, "env": self._install_env_vars()}
        if referenced:
            cache_value["referenced_env"] = hashlib.sha256(json.dumps(referenced, sort_keys=True).encode()).hexdigest()
        with self._env.cache.compare(cache_value, section, of_type) as (eq, old):
            if not eq:
                old_req: list[str] = old["req"] if isinstance(old, dict) else (old or [])
                if missing := sorted(set(old_req) - set(new_reqs)):
                    msg = f"pylock dependencies removed: {' '.join(missing)}"
                    raise Recreate(msg)
                if new_deps := sorted(set(new_reqs) - set(old_req)) or new_reqs:
                    req_file = Path(self._env.env_dir) / "pylock.txt"
                    req_file.write_text("\n".join(new_deps))
                    self._execute_installer(["--no-deps", "-r", str(req_file)], of_type)

    def _install_list_of_deps(  # ruff:ignore[complex-structure, too-many-branches]
        self,
        arguments: Sequence[Requirement | Package],
        section: str,
        of_type: str,
    ) -> None:
        groups: dict[str, list[str]] = defaultdict(list)
        config_settings: dict[str, str] = {}
        for arg in arguments:
            if isinstance(arg, Requirement):
                groups["req"].append(str(arg))
            elif isinstance(arg, (WheelPackage, SdistPackage, EditablePackage)):
                groups["req"].extend(self._apply_force_deps(arg.deps))
                groups["pkg"].append(str(arg.path))
                if isinstance(arg, SdistPackage) and arg.config_settings:
                    config_settings.update(arg.config_settings)
            elif isinstance(arg, EditableLegacyPackage):
                groups["req"].extend(self._apply_force_deps(arg.deps))
                groups["dev_pkg"].append(str(arg.path))
            else:
                logging.warning("pip cannot install %r", arg)
                raise SystemExit(1)
        req_of_type = f"{of_type}_deps" if groups["pkg"] or groups["dev_pkg"] else of_type
        for value in groups.values():
            value.sort()
        cache_value = {"req": groups["req"], "env": self._install_env_vars()}
        with self._env.cache.compare(cache_value, section, req_of_type) as (eq, old):
            if not eq:  # pragma: no branch
                old_req: list[str] = old["req"] if isinstance(old, dict) else (old or [])
                miss = sorted(set(old_req) - set(groups["req"]))
                if miss:  # no way yet to know what to uninstall here (transitive dependencies?)
                    msg = f"dependencies removed: {', '.join(str(i) for i in miss)}"
                    raise Recreate(msg)  # pragma: no branch
                new_deps = sorted(set(groups["req"]) - set(old_req)) or list(groups["req"])
                if new_deps:  # pragma: no branch
                    new_deps.extend(self.constraints.as_root_args)
                    self._execute_installer(new_deps, req_of_type)
        install_args = ["--force-reinstall", "--no-deps"]
        cs_args = [f"--config-settings={k}={v}" for k, v in config_settings.items()]
        if groups["pkg"]:
            # we intentionally ignore constraints when installing the package itself
            # https://github.com/tox-dev/tox/issues/3550
            self._execute_installer(install_args + cs_args + groups["pkg"], of_type)
        if groups["dev_pkg"]:
            for entry in groups["dev_pkg"]:
                install_args.extend(("-e", str(entry)))
            # we intentionally ignore constraints when installing the package itself
            # https://github.com/tox-dev/tox/issues/3550
            self._execute_installer(install_args, of_type)

    def _install_env_vars(self) -> dict[str, str]:
        """Return env vars that affect pip resolution and should be part of the install cache key."""
        return {k: v for k, v in self._env.environment_variables.items() if k in _PIP_RESOLUTION_ENV_VARS}

    def _apply_force_deps(self, deps: Sequence[Requirement]) -> list[str]:
        forced: dict[NormalizedName, Requirement] = {
            canonicalize_name(r.name): r for r in getattr(self._env.options, "force_dep", [])
        }
        return [str(forced.get(canonicalize_name(dep.name), dep)) for dep in deps]

    @property
    def _has_constraints(self) -> bool:
        return bool(self.constraints.as_root_args)

    def _execute_installer(self, deps: Sequence[Any], of_type: str) -> None:
        if of_type == "package_deps" and self.constrain_package_deps and not self._has_constraints:
            constraints_file = self.constraints_file()
            if constraints_file.exists():
                deps = [*deps, f"-c{constraints_file}"]

        cmd = self.build_install_cmd(deps)
        outcome = self._env.execute(cmd, stdin=StdinSource.OFF, run_id=f"install_{of_type}")
        outcome.assert_success()

        if (
            of_type == "deps"
            and self.constrain_package_deps
            and self.use_frozen_constraints
            and not self._has_constraints
        ):
            self.constraints_file().write_text("\n".join(self.installed()))

    def build_install_cmd(self, args: Sequence[str]) -> list[str]:
        install_command = self._env.conf.get("install_command", Command).args
        try:
            opts_at = install_command.index("{packages}")
        except ValueError:
            opts_at = len(install_command)
        return install_command[:opts_at] + list(args) + install_command[opts_at + 1 :]


__all__ = [
    "Pip",
    "PythonInstallerListDependencies",
]
