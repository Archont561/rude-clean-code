from __future__ import annotations

import bisect
import re
from argparse import Action, ArgumentParser, ArgumentTypeError, Namespace
from typing import TYPE_CHECKING, Any, NoReturn, Protocol, TypeVar, cast

from tox.util.typing_compat import override

if TYPE_CHECKING:
    from collections.abc import Sequence

_T_contra = TypeVar("_T_contra", contravariant=True)


# stable
class _SupportsWrite(Protocol[_T_contra]):
    def write(self, s: _T_contra, /) -> object: ...


class _OurArgumentParser(ArgumentParser):
    @override
    def print_usage(self, file: _SupportsWrite[str] | None = None) -> None:
        pass

    @override
    def exit(self, status: int = 0, message: str | None = None) -> NoReturn:
        message = "" if message is None else message
        msg = message.lstrip(": ").rstrip()
        msg = msg.removeprefix("error: ")
        raise ValueError(msg)


def build_parser() -> ArgumentParser:
    parser = _OurArgumentParser(add_help=False, prog="", allow_abbrev=False)
    _global_options(parser)
    _req_options(parser)
    return parser


def _global_options(parser: ArgumentParser) -> None:
    parser.add_argument("-i", "--index-url", "--pypi-url", dest="index_url", default=None)
    parser.add_argument("--extra-index-url", action=AddUniqueAction)
    parser.add_argument("--no-index", action="store_true", default=False)
    parser.add_argument("-c", "--constraint", action=AddUniqueAction, dest="constraints")
    parser.add_argument("-r", "--requirement", action=AddUniqueAction, dest="requirements")
    parser.add_argument("-e", "--editable", action=AddUniqueAction, dest="editables")
    parser.add_argument("-f", "--find-links", action=AddUniqueAction)
    parser.add_argument("--no-binary", action=BinaryAction, nargs="+", dest="binary_options", const="no_binary")
    parser.add_argument("--only-binary", action=BinaryAction, nargs="+", dest="binary_options", const="only_binary")
    parser.add_argument("--prefer-binary", action="store_true", default=False)
    parser.add_argument("--require-hashes", action="store_true", default=False)
    parser.add_argument("--pre", action="store_true", default=False)
    parser.add_argument("--trusted-host", action=AddSortedUniqueAction)
    parser.add_argument(
        "--use-feature",
        choices=["2020-resolver", "fast-deps"],
        action=AddSortedUniqueAction,
        dest="features_enabled",
    )


def _req_options(parser: ArgumentParser) -> None:
    parser.add_argument("--install-option", action=AddSortedUniqueAction)
    parser.add_argument("--global-option", action=AddSortedUniqueAction)
    parser.add_argument("--hash", action=AddSortedUniqueAction, type=_validate_hash)
    parser.add_argument("-C", "--config-settings", action="append", dest="config_settings")


_HASH = re.compile(
    r"""
    sha
    (
        256 : [a-f0-9]{64}      # SHA-256 hash
        | 384 : [a-f0-9]{96}    # SHA-384 hash
        | 512 : [a-f0-9]{128}   # SHA-512 hash
    )
    """,
    re.VERBOSE,
)


def _validate_hash(value: str) -> str:
    if not _HASH.fullmatch(value):
        raise ArgumentTypeError(value)
    return value


class AddSortedUniqueAction(Action):
    @override
    def __call__(
        self,
        parser: ArgumentParser,
        namespace: Namespace,
        values: str | Sequence[Any] | None,
        option_string: str | None = None,
    ) -> None:
        if getattr(namespace, self.dest, None) is None:
            setattr(namespace, self.dest, [])
        current = getattr(namespace, self.dest)
        if values is not None and values not in current:
            bisect.insort(current, cast("str", values))


class AddUniqueAction(Action):
    @override
    def __call__(
        self,
        parser: ArgumentParser,
        namespace: Namespace,
        values: str | Sequence[Any] | None,
        option_string: str | None = None,
    ) -> None:
        if getattr(namespace, self.dest, None) is None:
            setattr(namespace, self.dest, [])
        current = getattr(namespace, self.dest)
        if values not in current:
            current.append(values)


class BinaryAction(Action):
    # Every line parses into its own namespace, while pip lets a later line edit the sets of an earlier one, so record
    # the values in order for the merge to apply.
    @override
    def __call__(
        self,
        parser: ArgumentParser,
        namespace: Namespace,
        values: str | Sequence[Any] | None,
        option_string: str | None = None,
    ) -> None:
        assert values is not None  # ruff:ignore[assert]
        namespace.binary_options = [*(namespace.binary_options or []), (self.const, values[0])]
