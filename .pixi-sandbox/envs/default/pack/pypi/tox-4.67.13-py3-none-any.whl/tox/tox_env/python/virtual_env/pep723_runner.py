"""Concrete virtualenv-backed PEP 723 runner."""

from __future__ import annotations

from typing import TYPE_CHECKING

from tox.plugin import impl
from tox.tox_env.python.pep723 import Pep723Mixin
from tox.tox_env.runner import RunToxEnv
from tox.util.typing_compat import override

from .api import VirtualEnv

if TYPE_CHECKING:
    from tox.tox_env.package import Package
    from tox.tox_env.register import ToxEnvRegister


class Pep723Runner(Pep723Mixin, VirtualEnv, RunToxEnv):
    @staticmethod
    @override
    def id() -> str:
        return "virtualenv-pep-723"

    @override
    def _register_package_conf(self) -> bool:
        return False

    @property
    @override
    def _package_tox_env_type(self) -> str:
        raise NotImplementedError

    @property
    @override
    def _external_pkg_tox_env_type(self) -> str:
        raise NotImplementedError

    @override
    def _build_packages(self) -> list[Package]:
        return []


@impl
def tox_register_tox_env(register: ToxEnvRegister) -> None:
    register.add_run_env(Pep723Runner)


__all__ = [
    "Pep723Runner",
]
