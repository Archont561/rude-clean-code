"""Sources."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

from tox.config.loader.section import Section
from tox.util.typing_compat import override

if TYPE_CHECKING:
    from collections.abc import Iterator
    from pathlib import Path

    from tox.config.loader.api import Loader, OverrideMap
    from tox.config.sets import ConfigSet, CoreConfigSet
    from tox.config.types import FactorGroup


class Source(ABC):
    """Source is able to return a configuration value (for either the core or per environment source)."""

    FILENAME = ""

    def __init__(self, path: Path) -> None:
        self.path: Path = path  #: the path to the configuration source

    @override
    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(path={self.path})"

    def get_loaders(
        self,
        section: Section,
        base: list[str] | None,
        override_map: OverrideMap,
        conf: ConfigSet,
    ) -> Iterator[Loader[Any]]:
        """Return a loader that loads settings from a given section name.

        :param section: the section to load
        :param base: base sections to fallback to
        :param override_map: a list of overrides to apply
        :param conf: the config set to use

        :returns: the loaders to use

        """
        # loaders are built fresh per config set: their parent chain depends on the base sections, and a section can
        # be redefined with another base (a run env re-created as a package env); the config set is what gets cached
        section = self.transform_section(section)
        loader: Loader[Any] | None = self.get_loader(section, override_map)
        if loader is not None:
            yield loader

        if base is not None:
            conf.add_config(
                keys="base",
                of_type=list[str],
                desc="inherit missing keys from these sections",
                default=base,
            )
            for base_section in self.get_base_sections(conf["base"], section):
                child = loader
                loader = self.get_loader(base_section, override_map)
                if loader is None:
                    loader = child
                    continue
                if child is not None:
                    child.parent = loader
                yield loader

    @abstractmethod
    def transform_section(self, section: Section) -> Section:
        raise NotImplementedError

    @abstractmethod
    def get_loader(self, section: Section, override_map: OverrideMap) -> Loader[Any] | None:
        raise NotImplementedError

    @abstractmethod
    def get_base_sections(self, base: list[str], in_section: Section) -> Iterator[Section]:
        raise NotImplementedError

    @abstractmethod
    def sections(self) -> Iterator[Section]:
        """Return a loader that loads the core configuration values.

        :returns: the core loader from this source

        """
        raise NotImplementedError

    @abstractmethod
    def envs(self, core_conf: CoreConfigSet) -> Iterator[str]:
        """:param core_conf: the core configuration set

        :returns: a list of environments defined within this source

        """
        raise NotImplementedError

    @abstractmethod
    def get_tox_env_section(self, item: str) -> tuple[Section, list[str], list[str]]:
        """:returns: the section for a tox environment"""
        raise NotImplementedError

    @abstractmethod
    def get_core_section(self) -> Section:
        """:returns: the core section"""
        raise NotImplementedError


@runtime_checkable
class FactorLabelSource(Protocol):
    def factor_labels(self, env_name: str | None) -> dict[str, FactorGroup]: ...


__all__ = [
    "FactorLabelSource",
    "Section",
    "Source",
]
